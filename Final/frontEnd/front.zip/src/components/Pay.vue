<template>
  <div>
    <p>Pay</p>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped></style>
