<template>
  <div class="container">
    <div class="buttons-container">
      <el-button @click="goHome">首页</el-button>
      <el-button @click="gotoOrder">返回订单列表</el-button>
      <el-button style="background-color: #409EFF; color: white;">支付
      </el-button>
    </div>
    <div class="order-detail-container"
      style="background-color: #f5f5f5; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
      <el-card class="order-details-card" :shadow="hoverShadow" :body-style="{ padding: '20px' }">
        <div slot="header" class="order-card-header">
          <h2>Order Details</h2>
        </div>
        <div class="order-card-content">
          <p><strong>ID:</strong> {{ orderDetailsArray.id }}</p>
          <p><strong>User ID:</strong> {{ orderDetailsArray.userId }}</p>
          <p><strong>Room Number:</strong> {{ orderDetailsArray.roomNumber }}</p>
          <p><strong>Guest Name:</strong> {{ orderDetailsArray.guestName }}</p>
          <p><strong>Price:</strong> {{ orderDetailsArray.price }}</p>
          <p><strong>Guests Count:</strong> {{ orderDetailsArray.guestsCount }}</p>
          <p><strong>Check-In Date:</strong> {{ orderDetailsArray.checkInDate }}</p>
          <p><strong>Check-Out Date:</strong> {{ orderDetailsArray.checkOutDate }}</p>
          <p><strong>Status:</strong> {{ orderDetailsArray.status }}</p>
          <p><strong>Room Type:</strong> {{ orderDetailsArray.roomType }}</p>
          <p><strong>Order Time:</strong> {{ orderDetailsArray.orderTime }}</p>
          <p><strong>Phone Number:</strong> {{ orderDetailsArray.phoneNumber }}</p>
          <p><strong>Order Note:</strong> {{ orderDetailsArray.orderNote }}</p>
        </div>
      </el-card>
    </div>
  </div>
</template>
  
<script>
import { ElMessageBox } from 'element-plus';
export default {
  name: 'OrderDetail',
  data() {
    return {
      balance: 1000,
      detailForm: {
        id: ''
      },
      orderDetailsArray: []
    };
  },
  created() {
    const m = this.$route.params.id;
    console.log('id', m)
    this.detailForm = {
      id: m
    }
    this.$axios.post('http://localhost:8080/order/details', this.detailForm)
      .then(response => {
        this.orderDetailsArray = response.data.data;
      })
      .catch(error => {
        console.error('Error fetching hotels data:', error);
      });
  },
  methods: {
    goHome() {
      this.$router.push('/Home');
    },
    gotoOrder() {
      this.$router.push('/Order');
    }
  },
};
</script>
  
<style scoped>
.container {
  position: relative;
  padding: 20px;
  box-sizing: border-box;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.buttons-container {
  position: absolute;
  top: 20px;
  left: 20px;
}

.order-detail-container {
  width: 100%;
  max-width: 1000px;
}
</style>


  